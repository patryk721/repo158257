var searchData=
[
  ['triangle_0',['triangle',['../wmt-20201202_8cpp.html#ae8b3611ed226d86b941579d1b1b29e4d',1,'wmt-20201202.cpp']]]
];
